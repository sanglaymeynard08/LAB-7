# Lab-Act-No.-07_De-Vale

Creating a Registration Form

Instructions:
In this laboratory activity you are going to combine several of the form controls to make up a site registration form.
